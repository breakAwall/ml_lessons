from setuptools import setup

setup(name='kg100_distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['distributions'],
      author='Krishna Goel',
      author_email = 'kgoel100@gmail.com',
      zip_safe=False)
